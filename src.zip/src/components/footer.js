import React from 'react';
import { Container } from 'react-bootstrap';

const Footer = () => {
  return (
    <footer className="bg-dark text-white">
      <Container>
        <p>&copy; {new Date().getFullYear()} PeTIK II Jombang</p>
        <p>Contact us at: ilmanfaisocu26@email.com</p>
        <p>Address: Jombang, Jombang, Jawa Timur</p>
      </Container>
    </footer>
  );
};

export default Footer;