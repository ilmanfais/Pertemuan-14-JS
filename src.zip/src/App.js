import React from 'react';
import Header from './components/header';
import Footer from './components/footer';
import { Container } from 'react-bootstrap';

const appStyles = {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  minHeight: '100vh', // Membuat konten berada di tengah vertikal
};

const headingStyles = {
  color: 'blue',
};

function App() {
  return (
    <div style={appStyles}>
      <Header />
      <Container>
        <h1 style={headingStyles}>Selamat Datang di Tugas Pertemuan 14 Ilman</h1>
        <p>Ini belajar React JS</p>
      </Container>
      <Footer />
    </div>
  );
}

export default App;
